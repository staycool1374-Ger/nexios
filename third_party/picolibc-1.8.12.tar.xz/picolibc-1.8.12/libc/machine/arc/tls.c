/*
 * SPDX-License-Identifier: BSD-3-Clause
 *
 * Copyright © 2022 Keith Packard
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above
 *    copyright notice, this list of conditions and the following
 *    disclaimer in the documentation and/or other materials provided
 *    with the distribution.
 *
 * 3. Neither the name of the copyright holder nor the names of its
 *    contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 * COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
 * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
 * STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include <picotls.h>
#include <string.h>
#include <stdint.h>

#ifdef __THREAD_LOCAL_STORAGE_API

#ifdef __ARC_TLS_REGNO__
#define TLS_REGNO __ARC_TLS_REGNO__
#elif defined(__ARC64__)
#define TLS_REGNO 30
#else
#define TLS_REGNO 26
#endif

#ifdef __ARC64__
extern char __arc64_tls_tcb_offset[];
#define TP_OFFSET ((size_t)__arc64_tls_tcb_offset)
#else
extern char __arc_tls_tcb_offset[];
#define TP_OFFSET ((size_t)__arc_tls_tcb_offset)
#endif

#define _REG(n) "r" #n
#define REG(n)  _REG(n)

void
_set_tls(void *tls)
{
    tls = (uint8_t *)tls - TP_OFFSET;
    __asm__("mov " REG(TLS_REGNO) ", %0" : : "r"(tls));
}

#endif
